library(e1071)
source('MainProgram.r')
TestData=read.csv(file="Demo_Encoded_test_file.csv", header=TRUE, sep=",")
(class<-PredPTM(TestData))
