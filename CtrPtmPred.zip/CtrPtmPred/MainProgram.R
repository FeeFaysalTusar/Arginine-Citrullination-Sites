PredPTM<-function(TestData)
{
  load("Feature.RData")
  Data.featured=TestData[,position]
  
  load("Model.RData")
  library(e1071)
  class <-predict(model.svmR,Data.featured, levels = TRUE)
  return(class)
}

