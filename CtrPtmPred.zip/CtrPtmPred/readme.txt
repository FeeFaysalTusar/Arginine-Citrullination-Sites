###############################################################################
###  To utilize this prediction method one's should know how to 	#######
####   edit and run perl programes as well as R-programes. 		#######
###############################################################################
Step-01:
Firstly, you have to arrange some protein sequences to predict. You will create 
fragments with 21 window size from your sequences where center position will have
 a "R"following way as given below (e.g "Test_citrullination_site_fragmented_data.txt").
 This file will be used as input file for the CKSAAP encoding.


LSGIQGVPLSRTVRCTCISIS
TVVQGFPMFKRGRCLCIGPGV
NMNPMQAGVQRAGLPQQQPQQ
MMVGGLAPGRRLGPGTRLSLA
QALEEAAKADRDITEINNLTA
KKKQLRSIEKRDTLALLQKQP
LKTNSYGGKDRGEDEESRERM
IVQAVSSSKERSGVSLAALKK
ITKAVAASKERSGVSLAALKK
ITKAVAASKERSGVSLAALKK

Step-02:
 Then, you will create the encoded file. Run the perl file named "Cksaap_Encoding.pl"
 for encoding the sequences fragments.In this perl file, the input file is the 
 "Test_citrullination_site_data.txt" and give a suitable name of the output file with
 a ".csv" format(say "CKSAAP_Encoded_data.csv"). The ".csv file" contains the rows 
 according to the fragments. Then you will organise your encoded file the following
 way (e.g "Demo_Encoded_test_file.csv")
########################################################################################
Step-03:
Now, you have to open the R-programe file named "DemoFile.R". Then you read the encoded
 file (e.g. "Demo_Encoded_test_file.csv")in read section . After that, Run the following
 codes to see the predicted classes. The class are used as "yes=citrullinated site" and
 "no= non-citrullinated site". The every predicted class indicates the corresponding 
 position of residue tabulated in fragment file either it's citrullinated or not.

#### @@@@@@ For example, you may run the DemoFile.R in the CtrPtmPred Folder. @@@@@@####