	open(FILE,'./Test_citrullination_site_fragmented_data.txt')||die "$!";
	open(OUT,'>./CKSAAP_Encoded_data.csv')||die "$!";
		while ($tmptest=<FILE>){
				
			@tmp=split(/\t+/ , $tmptest);
			$str=$tmp[0];$tag=$tmp[4];
			chomp $tag;
			 print OUT $tag;
			for ($k=0;$k<=5;$k++)
			{
			
				$ntotal=21-$k-1;
				@AA=qw(A C D E F G H I K L M N P Q R S T V W Y -);
				 $str=~/[A-Z]/gi;
				%cp={};
				$sum=0;
				for($i=0; $i<length($str)-$k-1; $i++){
					$a=substr($str,$i,1);
					$b=substr($str,$i+$k+1,1);
					$key=$a.$b;
					$cp{$key}++;
				}
				@array=();
	
				for ($a=0;$a<=20; $a++){
					for ($b=0;$b<=20; $b++)
					{
						$key=$AA[$a].$AA[$b];
						
						$s++;
						push(@array, $cp{$key});
					}
				}
					for($j=0; $j<@array; $j++){
						$feavalue=$array[$j]/$ntotal;
						$index=$k*441+$j+1;
						  print OUT "\t$index:$feavalue";
					}
					
			}		
		    print OUT "\n";
		}
			close FILE;
			close OUT;

